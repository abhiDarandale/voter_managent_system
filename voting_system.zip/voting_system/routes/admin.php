<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login - Voting System</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-container {
            max-width: 400px;
            margin: 100px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .admin-header {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }
        .admin-form input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .admin-btn {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        .admin-btn:hover {
            background: #0056b3;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #007bff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h2>Admin Login</h2>
            <p>Access the admin panel</p>
        </div>
        
        <form action="../api/admin_login.php" method="post" class="admin-form">
            <input type="text" name="username" placeholder="Enter Username" required>
            <input type="password" name="password" placeholder="Enter Password" required>
            <button type="submit" class="admin-btn">Login as Admin</button>
        </form>
        
        <div class="back-link">
            <a href="../">← Back to Voter Login</a>
        </div>
    </div>
</body>
</html>
