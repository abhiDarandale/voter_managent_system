<?php
session_start();
if (!isset($_SESSION['userdata'])){
	header("location: ../");
}
$userdata = $_SESSION['userdata'];
$partiesdata = $_SESSION['partiesdata'];

// Show popup if voted successfully
$voted_success = false;
if (isset($_GET['voted']) && $_GET['voted'] == '1') {
    $voted_success = true;
}

if ($_SESSION['userdata']['status'] == 0) {
	$status = '<b style="color:red">Not Voted</b>';
} else {
	$status = '<b style="color:green">Voted</b>';
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>online voting system-Dashboard</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<style>
		#logoutbtn{
			color:white;
			background-color:blue;
			padding:10px;
			border-radius:3px;
			font-size: 15px;
			float: right;
		}
		#backbtn{
			color:white;
			background-color:blue;
			padding:10px;
			border-radius:3px;
			font-size: 15px;
			float: left;
		}
		#profile{
			background-color: white;
			width: 30%;
			padding: 20px;
			float: left;
		}
		#group{
			width: 60%;
			height: 320px;
			padding: 20px;
			float: right;
		}
		#votebtn{
			color:white;
			background-color:blue;
			padding:5px;
			font-size:15px;
			border-radius:5px;
		}
		#voted{
			color:white;
			background-color:green;
			padding:5px;
			font-size:15px;
			border-radius:5px;
		}
		.party-section {
			margin-bottom: 20px;
			padding: 15px;
			border: 1px solid #ddd;
			border-radius: 5px;
			box-shadow: 0 2px 8px rgba(0,0,0,0.03);
			background: white;
		}
	</style>
	<script>
	<?php if ($voted_success): ?>
		window.onload = function() {
			alert("Voted Successfully.!");
		}
	<?php endif; ?>
	</script>
</head>
<body>
<div id="main">
	<div id="header">
	   <a href="../">
	       <button id="backbtn">Back</button>
	   </a>
	   <a href="logout.php">
	      <button id="logoutbtn">Logout</button>	
	   </a>
	<h1 style="text-align: center;">online voting system</h1>
	</div>
	<hr>
    <div id="profile">
    	<center>
           <img src="../uploads/<?php echo $userdata['photo'] ?>" style="height: 110px; width: 110px;">
    	</center>
    	<br>
    	<b>Name:</b> <?php echo $userdata['name']?><br><br>
    	<b>Mobile:</b> <?php echo $userdata['mobile']?><br><br>
    	<b>Address:</b> <?php echo $userdata['address']?><br><br>
    	<b>Status:</b> <?php echo $status?>  <br><br>
    </div>
    <div id="group">
    	<h2>Available Parties</h2>
    	<?php
    	if ($_SESSION['partiesdata']) {
    		for ($i = 0; $i < count($partiesdata); $i++) {
    	?>
				<div class="party-section">
					<img src="../uploads/<?php echo $partiesdata[$i]['photo']?>" style="height: 80px; width: 80px; float:right; border-radius: 50%;"><br>
					<b>Party Name:</b> <?php echo $partiesdata[$i]['name']?><br><br>
					<b>Symbol:</b> <?php echo $partiesdata[$i]['symbol']?><br><br>
					<form action="../api/vote.php" method="post" onsubmit="return voteConfirm(this);">
					    <input type="hidden" name="party_id" value="<?php echo $partiesdata[$i]['id'] ?>">
					    <input type="hidden" name="party_name" value="<?php echo $partiesdata[$i]['name'] ?>">
						<?php
						if ($_SESSION['userdata']['status'] == 0) {
						?>
							<input type="submit" name="votebtn" value="Vote for <?php echo $partiesdata[$i]['name'] ?>" id="votebtn">
						<?php
						} else {
						?>
							<button disabled type="button" name="votebtn" value="voted" id="voted">Already Voted</button>
						<?php  
						}
						?>
					</form>
				</div>
    	<?php
    		}
    	} else {
    		echo '<p>No parties available for voting.</p>';
    	}
    	?>
    </div>
</div>
<script>
function voteConfirm(form) {

	return true;
}
</script>
</body>
</html>