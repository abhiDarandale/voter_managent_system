<?php
session_start();
if (!isset($_SESSION['admindata'])) {
    header("location: admin.php");
}
$admindata = $_SESSION['admindata'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vote Analytics - Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .admin-nav {
            background: #f8f9fa;
            padding: 15px;
            text-align: center;
        }
        .admin-nav a {
            margin: 0 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .admin-nav a:hover {
            background: #0056b3;
        }
        .analytics-content {
            padding: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .party-selector {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn {
            padding: 12px 25px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-success {
            background: #28a745;
        }
        .btn-success:hover {
            background: #218838;
        }
        .results-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .vote-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #007bff;
        }
        .voters-list {
            margin-top: 20px;
        }
        .voter-item {
            display: flex;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }
        .voter-item:last-child {
            border-bottom: none;
        }
        .voter-photo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
        }
        .voter-info {
            flex-grow: 1;
        }
        .voter-name {
            font-weight: bold;
        }
        .voter-mobile {
            color: #666;
            font-size: 14px;
        }
        .vote-time {
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Vote Analytics</h1>
        <p>Analyze voting patterns and results</p>
    </div>
    
    <div class="admin-nav">
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="admin_analytics.php">Vote Analytics</a>
        <a href="../api/admin_logout.php">Logout</a>
    </div>
    
    <div class="analytics-content">
        <!-- Party Selector -->
        <div class="party-selector">
            <h2>Select Party for Analysis</h2>
            <form method="post" action="">
                <div class="form-group">
                    <label>Choose Party:</label>
                    <select name="selected_party" onchange="this.form.submit()">
                        <option value="">Select a party...</option>
                        <?php
                        include("../api/connection.php");
                        $parties = mysqli_query($conn, "SELECT * FROM parties WHERE status=1 ORDER BY name");
                        while ($party = mysqli_fetch_array($parties)) {
                            $selected = (isset($_POST['selected_party']) && $_POST['selected_party'] == $party['id']) ? 'selected' : '';
                            echo '<option value="' . $party['id'] . '" ' . $selected . '>' . $party['name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
            </form>
        </div>
        
        <!-- Results -->
        <?php
        if (isset($_POST['selected_party']) && !empty($_POST['selected_party'])) {
            $party_id = $_POST['selected_party'];
            
            // Get party details
            $party_query = mysqli_query($conn, "SELECT * FROM parties WHERE id='$party_id'");
            $party = mysqli_fetch_array($party_query);
            
            // Get vote count for this party
            $vote_count_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM vote_records WHERE party_id='$party_id'");
            $vote_count = mysqli_fetch_array($vote_count_query)['count'];
            
            // Get total votes
            $total_votes_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM vote_records");
            $total_votes = mysqli_fetch_array($total_votes_query)['count'];
            
            // Get percentage
            $percentage = $total_votes > 0 ? round(($vote_count / $total_votes) * 100, 2) : 0;
            
            // Get voters who voted for this party
            $voters_query = mysqli_query($conn, "SELECT vr.*, u.name, u.mobile, u.photo 
                                                FROM vote_records vr 
                                                JOIN user1 u ON vr.voter_id = u.id 
                                                WHERE vr.party_id='$party_id' 
                                                ORDER BY vr.vote_time DESC");
        ?>
        
        <div class="results-container">
            <h2>Results for <?php echo $party['name']; ?></h2>
            
            <div class="vote-stats">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $vote_count; ?></div>
                    <div>Total Votes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $percentage; ?>%</div>
                    <div>Percentage</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_votes; ?></div>
                    <div>Total System Votes</div>
                </div>
            </div>
            
            <div style="text-align: center; margin-bottom: 20px;">
                <a href="../api/export_pdf.php?party_id=<?php echo $party_id; ?>" class="btn btn-success">Download PDF Report</a>
            </div>
            
            <h3>Voters who voted for <?php echo $party['name']; ?></h3>
            <div class="voters-list">
                <?php
                if (mysqli_num_rows($voters_query) > 0) {
                    while ($voter = mysqli_fetch_array($voters_query)) {
                        echo '
                        <div class="voter-item">
                            <img src="../uploads/' . $voter['photo'] . '" alt="' . $voter['name'] . '" class="voter-photo">
                            <div class="voter-info">
                                <div class="voter-name">' . $voter['name'] . '</div>
                                <div class="voter-mobile">Mobile: ' . $voter['mobile'] . '</div>
                            </div>
                            <div class="vote-time">
                                Voted on: ' . date('d/m/Y H:i:s', strtotime($voter['vote_time'])) . '
                            </div>
                        </div>
                        ';
                    }
                } else {
                    echo '<p>No votes recorded for this party yet.</p>';
                }
                ?>
            </div>
        </div>
        
        <?php
        }
        ?>
    </div>
</body>
</html>
