<?php
session_start();
if (!isset($_SESSION['admindata'])) {
    header("location: admin.php");
}
$admindata = $_SESSION['admindata'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard - Voting System</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .admin-nav {
            background: #f8f9fa;
            padding: 15px;
            text-align: center;
        }
        .admin-nav a {
            margin: 0 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .admin-nav a:hover {
            background: #0056b3;
        }
        .admin-content {
            padding: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #007bff;
        }
        .add-party-form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn {
            padding: 12px 25px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .parties-list {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .party-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
            position: relative;
        }
        .party-item:last-child {
            border-bottom: none;
        }
        .party-photo {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-right: 15px;
            object-fit: cover;
        }
        .party-info {
            flex-grow: 1;
        }
        .party-name {
            font-weight: bold;
            font-size: 18px;
        }
        .party-symbol {
            color: #666;
            margin-top: 5px;
        }
        .party-actions {
            display: flex;
            gap: 10px;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-danger:hover {
            background: #c82333;
        }
        .btn-edit {
            background: #ffc107;
            color: #212529;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .btn-edit:hover {
            background: #e0a800;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Admin Dashboard</h1>
        <p>Welcome, <?php echo $admindata['username']; ?></p>
    </div>
    
    <div class="admin-nav">
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="admin_analytics.php">Vote Analytics</a>
        <a href="../api/admin_logout.php">Logout</a>
    </div>
    
    <div class="admin-content">
        <!-- Statistics -->
        <div class="stats-container">
            <?php
            include("../api/connection.php");
            
            // Get total parties
            $total_parties = mysqli_query($conn, "SELECT COUNT(*) as count FROM parties WHERE status=1");
            $parties_count = mysqli_fetch_array($total_parties)['count'];
            
            // Get total voters
            $total_voters = mysqli_query($conn, "SELECT COUNT(*) as count FROM user1 WHERE role=1");
            $voters_count = mysqli_fetch_array($total_voters)['count'];
            
            // Get total votes
            $total_votes = mysqli_query($conn, "SELECT COUNT(*) as count FROM vote_records");
            $votes_count = mysqli_fetch_array($total_votes)['count'];
            ?>
            
            <div class="stat-card">
                <div class="stat-number"><?php echo $parties_count; ?></div>
                <div>Total Parties</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $voters_count; ?></div>
                <div>Total Voters</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $votes_count; ?></div>
                <div>Total Votes</div>
            </div>
        </div>
        
        <!-- Add Party Form -->
        <div class="add-party-form">
            <h2>Add New Party</h2>
            <form action="../api/add_party.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Party Name:</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Party Symbol:</label>
                    <input type="text" name="symbol" required>
                </div>
                <div class="form-group">
                    <label>Party Photo:</label>
                    <input type="file" name="photo" accept="image/*" required>
                </div>
                <button type="submit" class="btn">Add Party</button>
            </form>
        </div>
        
        <!-- Existing Parties -->
        <div class="parties-list">
            <h2>Existing Parties</h2>
            <?php
            $parties = mysqli_query($conn, "SELECT * FROM parties WHERE status=1 ORDER BY name");
            if (mysqli_num_rows($parties) > 0) {
                while ($party = mysqli_fetch_array($parties)) {
                    echo '
                    <div class="party-item">
                        <img src="../uploads/' . $party['photo'] . '" alt="' . $party['name'] . '" class="party-photo">
                        <div class="party-info">
                            <div class="party-name">' . $party['name'] . '</div>
                            <div class="party-symbol">Symbol: ' . $party['symbol'] . '</div>
                        </div>
                        <div class="party-actions">
                            <button class="btn-edit" onclick="editParty(' . $party['id'] . ')">Edit</button>
                            <button class="btn-danger" onclick="deleteParty(' . $party['id'] . ', \'' . $party['name'] . '\')">Delete</button>
                        </div>
                    </div>
                    ';
                }
            } else {
                echo '<p style="text-align: center; color: #666; padding: 20px;">No parties added yet.</p>';
            }
            ?>
        </div>
    </div>

    <script>
    function deleteParty(partyId, partyName) {
        if (confirm('Are you sure you want to delete the party "' + partyName + '"?\n\nThis action cannot be undone and will remove the party from the voting system.')) {
            // Create a form to submit the delete request
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = '../api/delete_party.php';
            
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'party_id';
            input.value = partyId;
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function editParty(partyId) {
        // Redirect to edit page 
        window.location.href = 'edit_party.php?id=' + partyId;
    }
    </script>
    </div>
</body>
</html>
