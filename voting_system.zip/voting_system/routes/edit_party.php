<?php
session_start();
if (!isset($_SESSION['admindata'])) {
    header("location: admin.php");
}

$party_id = $_GET['id'] ?? '';
if (empty($party_id)) {
    header("location: admin_dashboard.php");
}

include("../api/connection.php");
$party_query = mysqli_query($conn, "SELECT * FROM parties WHERE id='$party_id' AND status=1");
if (mysqli_num_rows($party_query) == 0) {
    header("location: admin_dashboard.php");
}
$party = mysqli_fetch_array($party_query);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Party - Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        .admin-header {
            background: #007bff;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .admin-nav {
            background: #f8f9fa;
            padding: 15px;
            text-align: center;
        }
        .admin-nav a {
            margin: 0 15px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .admin-nav a:hover {
            background: #0056b3;
        }
        .edit-form {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .current-image {
            text-align: center;
            margin: 20px 0;
        }
        .current-image img {
            max-width: 150px;
            max-height: 150px;
            border-radius: 10px;
            border: 2px solid #ddd;
        }
        .btn {
            padding: 12px 25px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>Edit Party</h1>
        <p>Update party information</p>
    </div>
    
    <div class="admin-nav">
        <a href="admin_dashboard.php">← Back to Dashboard</a>
        <a href="admin_analytics.php">Vote Analytics</a>
        <a href="../api/admin_logout.php">Logout</a>
    </div>
    
    <div class="edit-form">
        <h2>Edit Party: <?php echo $party['name']; ?></h2>
        
        <form action="../api/update_party.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="party_id" value="<?php echo $party['id']; ?>">
            
            <div class="form-group">
                <label>Party Name:</label>
                <input type="text" name="name" value="<?php echo $party['name']; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Party Symbol:</label>
                <input type="text" name="symbol" value="<?php echo $party['symbol']; ?>" required>
            </div>
            
            <div class="current-image">
                <p><strong>Current Photo:</strong></p>
                <img src="../uploads/<?php echo $party['photo']; ?>" alt="<?php echo $party['name']; ?>">
            </div>
            
            <div class="form-group">
                <label>Update Party Photo (optional):</label>
                <input type="file" name="photo" accept="image/*">
                <small style="color: #666;">Leave empty to keep current photo</small>
            </div>
            
            
            <button type="submit" class="btn">Update Party</button>
            <a href="admin_dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
