<?php
session_start();
include("connection.php");

// Check if admin is logged in
if (!isset($_SESSION['admindata'])) {
    echo '
    <script type="text/javascript">
        alert("Access denied! Please login as admin.");
        window.location.href="../routes/admin.php";
    </script>
    ';
    exit();
}

$name = $_POST['name'];
$symbol = $_POST['symbol'];
$created_by = $_SESSION['admindata']['id'];

// Handle file upload
$image = $_FILES['photo']['name'];
$image_tmp = $_FILES['photo']['tmp_name'];
$image_path = '../uploads/' . $image;

// Move uploaded file
if (move_uploaded_file($image_tmp, $image_path)) {
    // Insert party into database
    $sql = "INSERT INTO parties (name, symbol, photo, created_by, status) 
            VALUES ('$name', '$symbol', '$image', '$created_by', 1)";
    
    if (mysqli_query($conn, $sql)) {
        echo '
        <script type="text/javascript">
            alert("Party added successfully!");
            window.location.href="../routes/admin_dashboard.php";
        </script>
        ';
    } else {
        echo '
        <script type="text/javascript">
            alert("Error adding party: ' . mysqli_error($conn) . '");
            window.location.href="../routes/admin_dashboard.php";
        </script>
        ';
    }
} else {
    echo '
    <script type="text/javascript">
        alert("Error uploading image!");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
}
?>
