<?php
session_start();
include("connection.php");

$party_id = $_POST['party_id'];
$party_name = $_POST['party_name'];
$voter_id = $_SESSION['userdata']['id'];
$voter_ip = $_SERVER['REMOTE_ADDR'];

// Check if user has already voted
$check_vote = mysqli_query($conn, "SELECT * FROM vote_records WHERE voter_id='$voter_id'");
if (mysqli_num_rows($check_vote) > 0) {
    echo '
    <script type="text/javascript">
        alert("You have already voted!");
        window.location.href="../routes/dashboard.php";
    </script>
    ';
    exit();
}

// Record the vote
$record_vote = mysqli_query($conn, "INSERT INTO vote_records (voter_id, party_id, ip_address) VALUES ('$voter_id', '$party_id', '$voter_ip')");

// Update user status to voted
$update_user_status = mysqli_query($conn, "UPDATE user1 SET status=1 WHERE id='$voter_id'");

if($record_vote and $update_user_status)
{
    // Get updated parties data
    $parties = mysqli_query($conn, "SELECT * FROM parties WHERE status=1");
    $partiesdata = mysqli_fetch_all($parties, MYSQLI_ASSOC);

    $_SESSION['userdata']['status'] = 1;
    $_SESSION['partiesdata'] = $partiesdata;

    echo'
    <script type="text/javascript">
	alert("Vote cast successfully for ' . $party_name . '!");
	window.location.href="../routes/dashboard.php";
    </script>
    ';
}
else
{
    echo'
    <script type="text/javascript">
	alert("Some error occurred while casting vote. Please try again.");
	window.location.href="../routes/dashboard.php";
    </script>
    ';
}
?>