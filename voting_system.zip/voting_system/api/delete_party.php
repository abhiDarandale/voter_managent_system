<?php
session_start();
include("connection.php");

// Check if admin is logged in
if (!isset($_SESSION['admindata'])) {
    echo '
    <script type="text/javascript">
        alert("Access denied! Please login as admin.");
        window.location.href="../routes/admin.php";
    </script>
    ';
    exit();
}

$party_id = $_POST['party_id'];

// Validate party ID
if (empty($party_id) || !is_numeric($party_id)) {
    echo '
    <script type="text/javascript">
        alert("Invalid party ID.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
    exit();
}

// Check if party exists
$check_party = mysqli_query($conn, "SELECT * FROM parties WHERE id='$party_id' AND status=1");
if (mysqli_num_rows($check_party) == 0) {
    echo '
    <script type="text/javascript">
        alert("Party not found or already deleted.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
    exit();
}

$party_data = mysqli_fetch_array($check_party);
$party_name = $party_data['name'];
$party_photo = $party_data['photo'];

// Check if there are any votes for this party
$check_votes = mysqli_query($conn, "SELECT COUNT(*) as vote_count FROM vote_records WHERE party_id='$party_id'");
$vote_data = mysqli_fetch_array($check_votes);
$vote_count = $vote_data['vote_count'];

if ($vote_count > 0) {
    echo '
    <script type="text/javascript">
        alert("Cannot delete party \'' . $party_name . '\' because it has ' . $vote_count . ' votes. Please contact system administrator.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
    exit();
}

// Delete the party 
$delete_party = mysqli_query($conn, "UPDATE parties SET status=0 WHERE id='$party_id'");

if ($delete_party) {
    // Optionally delete the image file
    $image_path = '../uploads/' . $party_photo;
    if (file_exists($image_path)) {
        unlink($image_path);
    }
    
    echo '
    <script type="text/javascript">
        alert("Party \'' . $party_name . '\' has been deleted successfully.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
} else {
    echo '
    <script type="text/javascript">
        alert("Error deleting party. Please try again.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
}
?>
