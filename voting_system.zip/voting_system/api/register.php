<?php
include("connection.php");

// Get form data
$name = $_POST['name'] ?? '';
$mobile = $_POST['mobile'] ?? '';
$password = $_POST['password'] ?? '';
$cpassword = $_POST['cpassword'] ?? '';
$address = $_POST['address'] ?? '';
$role = $_POST['role'] ?? '';

// Validate all required fields
if (empty($name) || empty($mobile) || empty($password) || empty($cpassword) || empty($address) || empty($role)) {
    echo '
    <script type="text/javascript">
        alert("Please fill in all required fields.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Validate mobile number (10 digits)
if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo '
    <script type="text/javascript">
        alert("Mobile number must be exactly 10 digits.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Validate password length
if (strlen($password) < 3) {
    echo '
    <script type="text/javascript">
        alert("Password must be at least 3 characters long.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Validate password confirmation
if ($password !== $cpassword) {
    echo '
    <script type="text/javascript">
        alert("Password and confirm password do not match.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Check if mobile number already exists
$check_mobile = mysqli_query($conn, "SELECT * FROM user1 WHERE mobile='$mobile'");
if (mysqli_num_rows($check_mobile) > 0) {
    echo '
    <script type="text/javascript">
        alert("Mobile number already registered. Please use a different mobile number.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Validate image upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    echo '
    <script type="text/javascript">
        alert("Please upload a valid image file.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

$image = $_FILES['image']['name'];
$image_tmp = $_FILES['image']['tmp_name'];
$image_size = $_FILES['image']['size'];


// Validate image size (max 2MB)
if ($image_size > 2097152) {
    echo '
    <script type="text/javascript">
        alert("Image size must be less than 2MB.");
        window.location.href="../routes/register.html";
    </script>
    ';
    exit();
}

// Sanitize inputs
$name = mysqli_real_escape_string($conn, $name);
$mobile = mysqli_real_escape_string($conn, $mobile);
$password = mysqli_real_escape_string($conn, $password);
$cpassword = mysqli_real_escape_string($conn, $cpassword);
$address = mysqli_real_escape_string($conn, $address);
$role = mysqli_real_escape_string($conn, $role);

// Generate unique filename to avoid conflicts
$image_name = time() . '_' . $image;
$upload_path = '../uploads/' . $image_name;

// Move uploaded file
if (move_uploaded_file($image_tmp, $upload_path)) {
    // Insert user data into database
    $sql = "INSERT INTO user1 (name, mobile, password, cpassword, address, photo, role, status, votes) 
            VALUES ('$name', '$mobile', '$password', '$cpassword', '$address', '$image_name', '$role', '0', '0')";
    
    if (mysqli_query($conn, $sql)) {
        echo '
        <script type="text/javascript">
            alert("Registration successful! You can now login.");
            window.location.href="../";
        </script>
        ';
    } else {
        echo '
        <script type="text/javascript">
            alert("Registration failed. Please try again.");
            window.location.href="../routes/register.html";
        </script>
        ';
    }
} else {
    echo '
    <script type="text/javascript">
        alert("Failed to upload image. Please try again.");
        window.location.href="../routes/register.html";
    </script>
    ';
}
?>