<?php
session_start();
include("connection.php");

$mobile = $_POST['mobile'];
$password = $_POST['password'];
$role = $_POST['role'];

// Validate input fields
if (empty($mobile) || empty($password)) {
    echo '
    <script type="text/javascript">
        alert("Please fill in all fields.");
        window.location.href="../";
    </script>
    ';
    exit();
}

// Only allow voters (role=1) to login through this page
if ($role != 1) {
    echo '
    <script type="text/javascript">
        alert("Only registered voters can login here. Use admin panel for admin access.");
        window.location.href="../";
    </script>
    ';
    exit();
}

// First check if user exists in database
$user_exists = mysqli_query($conn, "SELECT * FROM user1 WHERE mobile='$mobile' AND role='$role'");

if (mysqli_num_rows($user_exists) == 0) {
    echo '
    <script type="text/javascript">
        alert("User not found. Please register first before logging in.");
        window.location.href="../";
    </script>
    ';
    exit();
}

// Now check credentials
$check = mysqli_query($conn, "SELECT * FROM user1 WHERE mobile='$mobile' AND password='$password' AND role='$role'");

if (mysqli_num_rows($check) > 0) {
    $userdata = mysqli_fetch_array($check);
    
    // Get parties from the new parties table
    $parties = mysqli_query($conn, "SELECT * FROM parties WHERE status=1");
    $partiesdata = mysqli_fetch_all($parties, MYSQLI_ASSOC);

    $_SESSION['userdata'] = $userdata;
    $_SESSION['partiesdata'] = $partiesdata;
    
    echo '
    <script type="text/javascript">
        alert("Login successful! Welcome ' . $userdata['name'] . '");
        window.location.href="../routes/dashboard.php";
    </script>
    ';
} else {
    echo '
    <script type="text/javascript">
        alert("Incorrect password. Please check your password and try again.");
        window.location.href="../";
    </script>
    ';
}
?>