<?php
session_start();
include("connection.php");

$username = $_POST['username'];
$password = $_POST['password'];

// Check admin credentials
$check = mysqli_query($conn, "SELECT * FROM admin_users WHERE username='$username' AND password='$password' AND status=1");

if (mysqli_num_rows($check) > 0) {
    $admindata = mysqli_fetch_array($check);
    
    $_SESSION['admindata'] = $admindata;
    
    echo '
    <script type="text/javascript">
        alert("Admin login successful!");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
} else {
    echo '
    <script type="text/javascript">
        alert("Invalid admin credentials!");
        window.location.href="../routes/admin.php";
    </script>
    ';
}
?>
