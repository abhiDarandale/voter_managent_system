<?php
session_start();
include("connection.php");

// Check if admin is logged in
if (!isset($_SESSION['admindata'])) {
    echo '
    <script type="text/javascript">
        alert("Access denied! Please login as admin.");
        window.location.href="../routes/admin.php";
    </script>
    ';
    exit();
}

$party_id = $_POST['party_id'];
$name = $_POST['name'];
$symbol = $_POST['symbol'];

// Validate required fields
if (empty($party_id) || empty($name) || empty($symbol)) {
    echo '
    <script type="text/javascript">
        alert("Please fill in all required fields.");
        window.location.href="../routes/edit_party.php?id=' . $party_id . '";
    </script>
    ';
    exit();
}

// Check if party exists
$check_party = mysqli_query($conn, "SELECT * FROM parties WHERE id='$party_id' AND status=1");
if (mysqli_num_rows($check_party) == 0) {
    echo '
    <script type="text/javascript">
        alert("Party not found.");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
    exit();
}

$old_party_data = mysqli_fetch_array($check_party);
$old_photo = $old_party_data['photo'];

// Sanitize inputs
$name = mysqli_real_escape_string($conn, $name);
$symbol = mysqli_real_escape_string($conn, $symbol);

// Handle image upload if new image is provided
$new_photo = $old_photo; // Keep old photo by default

if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $image = $_FILES['photo']['name'];
    $image_tmp = $_FILES['photo']['tmp_name'];
    $image_size = $_FILES['photo']['size'];
    
    // Validate image file type
    $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
    $image_extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    
    if (!in_array($image_extension, $allowed_extensions)) {
        echo '
        <script type="text/javascript">
            alert("Please upload a valid image file (jpg, jpeg, png, gif only).");
            window.location.href="../routes/edit_party.php?id=' . $party_id . '";
        </script>
        ';
        exit();
    }
    
    // Validate image size (max 2MB)
    if ($image_size > 2097152) {
        echo '
        <script type="text/javascript">
            alert("Image size must be less than 2MB.");
            window.location.href="../routes/edit_party.php?id=' . $party_id . '";
        </script>
        ';
        exit();
    }
    
    // Generate unique filename
    $new_photo = time() . '_' . $image;
    $upload_path = '../uploads/' . $new_photo;
    
    // Move uploaded file
    if (move_uploaded_file($image_tmp, $upload_path)) {
        // Delete old image file
        $old_image_path = '../uploads/' . $old_photo;
        if (file_exists($old_image_path)) {
            unlink($old_image_path);
        }
    } else {
        echo '
        <script type="text/javascript">
            alert("Failed to upload new image. Please try again.");
            window.location.href="../routes/edit_party.php?id=' . $party_id . '";
        </script>
        ';
        exit();
    }
}

// Update party in database
$sql = "UPDATE parties SET name='$name', symbol='$symbol', photo='$new_photo' WHERE id='$party_id'";

if (mysqli_query($conn, $sql)) {
    echo '
    <script type="text/javascript">
        alert("Party updated successfully!");
        window.location.href="../routes/admin_dashboard.php";
    </script>
    ';
} else {
    echo '
    <script type="text/javascript">
        alert("Error updating party. Please try again.");
        window.location.href="../routes/edit_party.php?id=' . $party_id . '";
    </script>
    ';
}
?>
